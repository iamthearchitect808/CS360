package com.zybooks.nathanielholcombeproject2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.RecyclerViewHolder> {

    // variable for event array list and context
    private List<EventEntity> eventDataList;
    private Context mContext;

    // constructor
    public RecyclerViewAdapter(List<EventEntity> eventDataList, Context mContext) {
        this.eventDataList = eventDataList;
        this.mContext = mContext;
    }

    public RecyclerViewAdapter(Context mContext) {}

    // Handler for recycler view
    public class RecyclerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        //private int eventIndex;
        private TextView eventTimeTV;
        private TextView eventNameTV;
        private TextView eventDescTV;
        private ImageButton eventEditButton;
        private ImageButton eventDeleteButton;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            // To initialize text views
            eventTimeTV = itemView.findViewById(R.id.idEventDateTime);
            eventNameTV = itemView.findViewById(R.id.idTVEventTitle);
            eventDescTV = itemView.findViewById(R.id.idTVEventDesc);
            eventEditButton = itemView.findViewById(R.id.edit_event);
            eventDeleteButton = itemView.findViewById(R.id.delete_event);
            eventEditButton.setOnClickListener(this);
            eventDeleteButton.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.edit_event:
                    Intent intent = new Intent(mContext, EditEventActivity.class);
                    intent.putExtra("data", eventNameTV.getText());
                    intent.putExtra("description", eventDescTV.getText());
                    intent.putExtra("position", getAdapterPosition());
                    mContext.startActivity(intent);
                    break;

                case R.id.delete_event:
                    UserDatabase userDatabase = UserDatabase.getInstance(mContext);
                    EventDao eventDao = userDatabase.eventDao();
                    EventEntity eventData = userDatabase.eventDao().getEvent(eventNameTV.getText().toString(), eventDescTV.getText().toString());
                    long eventId = eventData.getId();
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            eventDao.deleteEvent(eventId);
                        }
                    }).start();
                    Intent deleteIntent = new Intent(mContext, MainActivity.class);
                    mContext.startActivity(deleteIntent);
                    break;
                default:
                    break;
            }
        }
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // inflate layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_event, parent, false);
        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        // Set data to textview from model event
        EventEntity recyclerData = eventDataList.get(position);
        int hour = recyclerData.getHour();
        int minute = recyclerData.getMinute();
        String time = recyclerData.getTime(hour, minute);
        holder.eventTimeTV.setText(time);
        holder.eventNameTV.setText(recyclerData.getText());
        holder.eventDescTV.setText(recyclerData.getDesc());
    }

    @Override
    public int getItemCount() {
        return eventDataList.size();
    }
}
