package com.zybooks.nathanielholcombeproject2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.autofill.UserData;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SendSMS extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_s_m_s);


        final TextView askPermission = (TextView) findViewById(R.id.askSMS);
        final Button smsYes = (Button) findViewById(R.id.SMS_yes);
        final Button smsNo = (Button) findViewById(R.id.SMS_no);
        Context mContext = getApplicationContext();

        smsYes.setOnClickListener(buttonClickListener);
        smsNo.setOnClickListener(buttonClickListener);

    }

    private View.OnClickListener buttonClickListener = new View.OnClickListener() {
        public void onClick(View v) {
            UserDatabase userDatabase = UserDatabase.getInstance(getApplicationContext());
            UserDao userDao = userDatabase.userDao();
            String name = getIntent().getStringExtra("nameOfUser");
            switch (v.getId()) {
                case R.id.SMS_yes:
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            userDao.updateSMSYes(name);
                        }
                    }).start();
                    break;
                case R.id.SMS_no:
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            userDao.updateSMSNo(name);
                        }
                    }).start();
                    break;
                default:
                    break;
            }
            startActivity(new Intent(
                    SendSMS.this, MainActivity.class));
        }
    };
}