package com.zybooks.nathanielholcombeproject2;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface UserDao {

    @Query("SELECT * FROM users WHERE username = (:username) AND password = (:password)")
    UserEntity login(String username, String password);

    @Query("SELECT * FROM users WHERE name = :name")
    UserEntity getName(String name);

    @Query("SELECT SMSPreference FROM users WHERE name = :name")
    String getPreference(String name);

    @Query("UPDATE users SET SMSPreference = 'yes' WHERE name = :name")
    void updateSMSYes(String name);

    @Query("UPDATE users SET SMSPreference = 'no' WHERE name = :name")
    void updateSMSNo(String name);

    @Insert(onConflict = OnConflictStrategy.ABORT)
    void registerUser(UserEntity userEntity);

    @Update
    public void updateUser(UserEntity userEntity);

    @Delete
    public void deleteUser(UserEntity userEntity);

}
