package com.zybooks.nathanielholcombeproject2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText username, password;
    Button login, register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        username = (EditText)findViewById(R.id.userLoginText);
        password = (EditText)findViewById(R.id.passwordText);
        login = findViewById(R.id.loginButton);
        register = findViewById(R.id.registerButton);
        UserEntity userEntity = new UserEntity();

        username.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                userEntity.setUsername(username.getText().toString());
            }
        });

        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                userEntity.setPassword(password.getText().toString());
            }
        });
    }

    public void UserLogin(View view) {
        // Login button was clicked
        if (username.getText().toString().isEmpty() || password.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "Fill both fields!", Toast.LENGTH_SHORT).show();
        } else {
            UserDatabase userDatabase = UserDatabase.getInstance(getApplicationContext());
            final UserDao userDao = userDatabase.userDao();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    UserEntity userEntity = userDao.login(username.getText().toString(), password.getText().toString());
                    if (userEntity == null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(), "Invalid credentials", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        startActivity(new Intent(
                                LoginActivity.this, MainActivity.class)
                                .putExtra("name", userEntity.getName().toString()));
                    }
                }
            }).start();
        }
    }

    public void RegisterUser(View view) {
        // Register button was clicked - go to fragment to register new user
        startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
    }
}