package com.zybooks.nathanielholcombeproject2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditEventActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_event);

        final RecyclerViewAdapter recyclerViewAdapter = new RecyclerViewAdapter(this);

        final EditText editTitle = (EditText)findViewById(R.id.edit_title);
        final EditText editDesc = (EditText)findViewById(R.id.edit_desc);
        final Button saveButton = (Button)findViewById(R.id.save_changes);
        String text = (String) getIntent().getStringExtra("data");
        String description = (String) getIntent().getStringExtra("description");
        editTitle.setText(text);
        editDesc.setText(description);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserDatabase userDatabase = UserDatabase.getInstance(getApplicationContext());
                EventDao eventDao = userDatabase.eventDao();
                EventEntity eventData = userDatabase.eventDao().getEvent(text, description);
                long eventId = eventData.getId();
                if(editTitle.getText().toString() != text || editDesc.getText().toString() != description) {
                    eventData.setText(editTitle.getText().toString());
                    eventData.setText(editDesc.getText().toString());
                    eventData.setText(editTitle.getText().toString());
                    eventData.setDesc(editDesc.getText().toString());

                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            //Update event in Database
                            eventDao.updateEvent(eventData);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(), "Changes saved.", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }).start();
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                }
            }
        });
    }
}