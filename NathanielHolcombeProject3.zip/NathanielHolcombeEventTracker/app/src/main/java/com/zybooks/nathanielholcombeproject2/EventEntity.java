package com.zybooks.nathanielholcombeproject2;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(tableName = "events")

public class EventEntity {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "eId")
    private long id;

    @ColumnInfo(name = "nameOfUser")
    private String nameOfUser;

    @ColumnInfo(name = "eventTitle")
    private String text;

    @ColumnInfo(name = "eventDesc")
    private String desc;

    @ColumnInfo(name = "dayOfMonth")
    private int dayOfMonth;

    @ColumnInfo(name = "eventMonth")
    private int month;

    @ColumnInfo(name = "eventYear")
    private int year;

    @ColumnInfo(name = "date")
    private String date;

    @ColumnInfo(name = "firstDayOfWeek")
    private int firstDayOfWeek;

    @ColumnInfo(name = "eventHour")
    private int hour;

    @ColumnInfo(name = "eventMinute")
    private int minute;

    public String getNameOfUser() { return nameOfUser; }

    public void setNameOfUser(String nameOfUser) { this.nameOfUser = nameOfUser; }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getDayOfMonth() {
        return dayOfMonth;
    }

    public void setDayOfMonth(int dayOfMonth) {
        this.dayOfMonth = dayOfMonth;
    }

    public int getMonth() { return month; }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() { return year; }

    public void setYear(int year) {
        this.year = year;
    }

    public int getFirstDayOfWeek() { return firstDayOfWeek; }

    public void setFirstDayOfWeek(int firstDayOfWeek) {
        this.firstDayOfWeek = firstDayOfWeek;
    }

    public String getDate() { return date; }

    public void setDate(String date) { this.date = date; }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public String getTime(int hour, int minute) {
        String aMpM;
        if(hour >= 12) {
            hour -= 12;
            aMpM = "PM";
        } else {
            aMpM = "AM";
        }
        String strMinute = String.valueOf(minute);
        String strHour = String.valueOf(hour);
        String time = strHour + ":" + strMinute + aMpM;
        return time;
    }


}
