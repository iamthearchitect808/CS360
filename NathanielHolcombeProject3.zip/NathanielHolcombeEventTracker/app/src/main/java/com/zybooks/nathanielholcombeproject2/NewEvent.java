package com.zybooks.nathanielholcombeproject2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

public class NewEvent extends AppCompatActivity {

    DatePicker eventDate;
    TimePicker eventTime;
    EditText title, description;
    Button saveEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_event);

        title = (EditText) findViewById(R.id.new_event_title);
        description = (EditText) findViewById(R.id.new_event_description);

        eventDate = (DatePicker) findViewById(R.id.event_date);
        eventTime = (TimePicker) findViewById(R.id.new_event_time);
        saveEvent = (Button) findViewById(R.id.save_event);
        eventTime.setIs24HourView(false);


        title.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        description.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        eventDate.setOnDateChangedListener(new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

            }
        });

        eventTime.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {

            }
        });
    }

    // When CREATE button is clicked, a new event is added to the Event table in UserDatabase
    public void CreateEvent(View view) {
        //String username = getIntent().getStringExtra("nameOfUser");
        EventEntity eventEntity = new EventEntity();
        eventEntity.setNameOfUser(getIntent().getStringExtra("nameOfUser"));
        eventEntity.setText(title.getText().toString());
        eventEntity.setDesc(description.getText().toString());
        eventEntity.setDayOfMonth(eventDate.getDayOfMonth());
        eventEntity.setFirstDayOfWeek(eventDate.getFirstDayOfWeek());
        eventEntity.setMonth(eventDate.getMonth());
        eventEntity.setYear(eventDate.getYear());
        eventEntity.setDate(makeDate(eventDate.getYear(), eventDate.getMonth(), eventDate.getDayOfMonth()));
        eventEntity.setHour(eventTime.getHour());
        eventEntity.setMinute(eventTime.getMinute());

        if(validateDateInput(eventEntity)) {
            UserDatabase userDatabase = UserDatabase.getInstance(getApplicationContext());
            EventDao eventDao = userDatabase.eventDao();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    // Insert event in UserDatabase
                    eventDao.insertEvent(eventEntity);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Event added", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }).start();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
    }

    private Boolean validateDateInput(EventEntity eventEntity) {
        if (eventEntity.getText().isEmpty() ||
                eventEntity.getDesc().isEmpty()) {
            return false;
        }
        return true;
    }

    private String makeDate(int whichYear, int whichMonth, int whichDay) {
        String date;
        String year = String.valueOf(whichYear);
        String month = String.valueOf(whichMonth);
        String day = String.valueOf(whichDay);
        date = year + "." + month + "." + day;
        return date;
    }
}