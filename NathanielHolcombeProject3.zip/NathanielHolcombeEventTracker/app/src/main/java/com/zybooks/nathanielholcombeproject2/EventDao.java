package com.zybooks.nathanielholcombeproject2;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;


@Dao
public interface EventDao {

    @Query("SELECT * FROM events")
    public List<EventEntity> getEvents();

    @Query("SELECT * FROM events WHERE nameOfUser = :nameOfUser")
    public List<EventEntity> getEvents(String nameOfUser);

    @Query("SELECT * FROM events WHERE eventTitle = :text AND eventDesc = :desc")
    public EventEntity getEvent(String text, String desc);

    @Query("SELECT * FROM events ORDER BY eventHour DESC")
    public List<EventEntity> getEventsNewerFirst();

    @Query("SELECT * FROM events WHERE date = :date")
    public List<EventEntity> todayEvents(String date);

    @Query("UPDATE events SET eventTitle = :text, eventDesc = :desc WHERE eId = :id")
    public void updateEvent(String text, String desc, long id);

    @Query("DELETE FROM events WHERE eId = :id")
    public void deleteEvent(long id);

    @Query("INSERT INTO events VALUES (:nameOfUser, :text, :desc, :id, :dom, :mo, :year, :date, :dow, :hour, :minute)")
    public void insertEvent(String nameOfUser, String text, String desc, long id, int dom, int mo,
                            int year, String date, int dow, int hour, int minute);

    @Insert(onConflict = OnConflictStrategy.ABORT)
    public void insertEvent(EventEntity eventEntity);

    @Update
    public void updateEvent(EventEntity eventEntity);

    @Delete
    public void deleteEvent(EventEntity eventEntity);
}
