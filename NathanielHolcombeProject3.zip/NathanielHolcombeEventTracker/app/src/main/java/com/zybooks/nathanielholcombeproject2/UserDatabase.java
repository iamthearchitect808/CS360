package com.zybooks.nathanielholcombeproject2;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {UserEntity.class, EventEntity.class}, version = 1)
public abstract class UserDatabase extends RoomDatabase {

    private static final String DATABASE_NAME = "userdatabase.db";
    private static UserDatabase userDatabase;

    public static UserDatabase getInstance(Context context) {
        if (userDatabase == null) {
            userDatabase = Room.databaseBuilder(context, UserDatabase.class,
                    DATABASE_NAME).allowMainThreadQueries().build();
        }
        return userDatabase;
    }

    public abstract UserDao userDao();
    public abstract EventDao eventDao();
}
