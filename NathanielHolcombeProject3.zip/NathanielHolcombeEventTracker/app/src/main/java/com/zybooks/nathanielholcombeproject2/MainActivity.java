package com.zybooks.nathanielholcombeproject2;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.usage.UsageEvents;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.EventLog;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.Fragment;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import androidx.appcompat.widget.Toolbar;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.telephony.SmsManager;

import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private UserDatabase mDatabase;
    private EventDao eventDao;
    private UserDao userDao;
    private RecyclerView eventRV;
    private List<EventDataController> eventDataControllerArrayList;
    private RecyclerViewAdapter recyclerViewAdapter;
    private EventEntity eventEntity;
    private static final int PERMISSIONS_REQUEST_SEND_SMS = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Custom toolbar
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Singleton database instance
        mDatabase = UserDatabase.getInstance(getApplicationContext());
        eventDao = mDatabase.eventDao();

        // RecyclerView for event cards
        eventRV = findViewById(R.id.idRVEvent);

        // current user logged in
        String nameOfUser = getIntent().getStringExtra("name");

        // List of all events from database
        List<EventEntity> allEvents = mDatabase.eventDao().getEvents();

        if (allEvents.size() > 0) {
            eventRV.setVisibility(View.VISIBLE);
            RecyclerViewAdapter mAdapter = new RecyclerViewAdapter(allEvents, this);
            eventRV.setAdapter(mAdapter);
        }
        else {
            eventRV.setVisibility(View.GONE);
            Toast.makeText(this, "No events in database. Add new event.", Toast.LENGTH_LONG).show();
        }

        // Initialize adapter class with array list and context
        recyclerViewAdapter = new RecyclerViewAdapter(allEvents, this);

        // Initialize layout manager
        LinearLayoutManager manager = new LinearLayoutManager(this);

        // Set layout manager for recycler view
        eventRV.setLayoutManager(manager);

        // Set adapter to recycler view
        eventRV.setAdapter(recyclerViewAdapter);

        // Create notifications if SMS is enabled
        sendSMSMessage();

    }

    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_new_event) {
            String nameOfUser = getIntent().getStringExtra("name");
            startActivity(new Intent(
                    MainActivity.this, NewEvent.class).putExtra("nameOfUser", nameOfUser));
        }
        else if (item.getItemId() == R.id.action_logout) {
            Toast.makeText(this, "Clicked Logout...", Toast.LENGTH_SHORT).show();
        }
        else if (item.getItemId() == R.id.action_SMS) {
            String nameOfUser = getIntent().getStringExtra("name");
            startActivity(new Intent(
                    MainActivity.this, SendSMS.class).putExtra("nameOfUser", nameOfUser));
        }
        return super.onOptionsItemSelected(item);
    }

    public boolean checkSMSPrefs(String nameOfUser) {
        boolean SMS = false;
        if (userDao != null) {
            if (userDao.getPreference(nameOfUser).equals("yes")) {
                SMS = true;
            } else if (userDao.getPreference(nameOfUser).equals("no")) {
                SMS = false;
            }
        }
        return SMS;
    }

    public List<EventEntity> findTodayEvents() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
        String currentDate = sdf.format(new Date());
        List<EventEntity> notifyList = eventDao.todayEvents(currentDate);
        return notifyList;
    }

    protected void sendSMSMessage() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS},
                        PERMISSIONS_REQUEST_SEND_SMS);
            }
        }
    }

    public void makeSMS(String name) {
        if (checkSMSPrefs(name) == true) {
            // Make list of today's events
            List<EventEntity> todayEvents = findTodayEvents();
            if (todayEvents.size() > 0) {
                // Create an SMS for each item in today's events list
                for (int i = 0; i < todayEvents.size(); ++i) {
                    EventEntity eventEntity = todayEvents.get(i);
                    String title = eventEntity.getText().toString();
                    int hour = eventEntity.getHour();
                    int minute = eventEntity.getMinute();
                    String time = eventEntity.getTime(hour, minute);
                    String message = "Event today: " + title + " at " + time;
                    String phoneNo = "6505551212";
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNo, null, message, null, null);
                    Intent smsIntent = new Intent(Intent.ACTION_VIEW);
                    smsIntent.setData(Uri.parse("smsto:"));
                    smsIntent.setType("vnd.android-dir/mms-sms");
                    smsIntent.putExtra("address" , phoneNo);
                    smsIntent.putExtra("sms_body" , message);
                    try {
                        startActivity(smsIntent);
                        finish();
                        Log.i("Finished sending SMS...", "");
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(MainActivity.this, "SMS failed, please try again later.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }

    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults, String name) {
        switch (requestCode) {
            case PERMISSIONS_REQUEST_SEND_SMS: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    makeSMS(name);
                } else {
                    Toast.makeText(getApplicationContext(),
                            "SMS failed, please try again.", Toast.LENGTH_LONG).show();
                    return;
                }
            }
        }
    }
}